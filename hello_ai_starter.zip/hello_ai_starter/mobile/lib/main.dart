import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Replace with your HTTPS backend URL before deploying.
// For a phone talking to a computer on the same Wi-Fi, use the computer's LAN IP.
const apiBaseUrl = 'https://YOUR_BACKEND_HOST';

void main() => runApp(const HelloAiApp());

class HelloAiApp extends StatelessWidget {
  const HelloAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HELLO AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090D18),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF8B5CF6),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool preparing = false;
  String status = 'A shirye nake in saurareka.';
  final messages = <String>[
    'Barka! Ni ce Hello AI 🤖',
    'Ki yi magana da ni da Hausa ko Turanci.',
  ];

  Future<void> prepareVoiceSession() async {
    setState(() {
      preparing = true;
      status = 'Ana shirya zaman murya...';
    });

    try {
      final response = await http.post(
        Uri.parse('$apiBaseUrl/realtime-token'),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode != 200) {
        throw Exception('Backend ya dawo da kuskure: ${response.statusCode}');
      }
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final secret = data['client_secret'] as String?;
      if (secret == null || secret.isEmpty) {
        throw Exception('Ba a samu token ba.');
      }

      // SECURITY: This is a short-lived token, not the permanent API key.
      // Next step: pass it to the native WebRTC session adapter, request microphone
      // permission, connect the audio tracks, and handle Realtime data-channel events.
      if (!mounted) return;
      setState(() {
        status = 'An shirya token. Mataki na gaba shi ne haɗa WebRTC audio.';
        messages.add('An shirya zaman murya. Ana buƙatar haɗa WebRTC domin a fara ji da magana.');
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => status = 'Ba a haɗu ba. Duba backend da intanet.');
    } finally {
      if (mounted) setState(() => preparing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('HELLO AI 🤖', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: Colors.transparent,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            children: [
              const SizedBox(height: 24),
              Container(
                width: 132,
                height: 132,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [Color(0xFF8B5CF6), Color(0xFF2563EB)],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF8B5CF6).withOpacity(.28),
                      blurRadius: 36,
                      spreadRadius: 4,
                    )
                  ],
                ),
                child: const Icon(Icons.graphic_eq_rounded, size: 66, color: Colors.white),
              ),
              const SizedBox(height: 20),
              const Text('BARKA! NI CE HELLO AI',
                  style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text(status, textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white.withOpacity(.68))),
              const SizedBox(height: 26),
              Expanded(
                child: ListView.separated(
                  itemCount: messages.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) => Align(
                    alignment: Alignment.centerLeft,
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFF171E30),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: Text(messages[index]),
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: 86,
                height: 86,
                child: FilledButton(
                  onPressed: preparing ? null : prepareVoiceSession,
                  style: FilledButton.styleFrom(
                    shape: const CircleBorder(),
                    backgroundColor: const Color(0xFF7C3AED),
                  ),
                  child: preparing
                      ? const CircularProgressIndicator()
                      : const Icon(Icons.mic_rounded, size: 38),
                ),
              ),
              const SizedBox(height: 10),
              const Text('Fara shirya tattaunawar murya',
                  style: TextStyle(color: Colors.white60, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}
