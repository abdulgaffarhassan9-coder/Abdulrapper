import "dotenv/config";
import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";

const app = express();
app.use(express.json({ limit: "32kb" }));
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || false }));
app.use(rateLimit({ windowMs: 60_000, limit: 20 }));

const instructions = `
You are HELLO AI, a warm, witty female-presenting Hausa voice companion.
Speak naturally and concisely. Prefer Hausa when the user speaks Hausa; understand
English too. Use light, kind humor and playful wordplay, never cruel insults.
Keep replies short unless the user asks for detail. Ask one question at a time.
Do not claim to be human. If you do not understand a Hausa phrase, politely ask
the user to repeat it. Respect privacy and do not request passwords or secret keys.
`;

app.get("/health", (_req, res) => res.json({ ok: true, app: "HELLO AI" }));

app.post("/realtime-token", async (_req, res) => {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return res.status(503).json({ error: "Backend API key is not configured." });

  try {
    const upstream = await fetch("https://api.openai.com/v1/realtime/client_secrets", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        expires_after: { anchor: "created_at", seconds: 600 },
        session: {
          type: "realtime",
          model: "gpt-realtime-2.1",
          instructions,
          output_modalities: ["audio"],
          audio: {
            input: {
              turn_detection: { type: "server_vad" },
              noise_reduction: { type: "near_field" }
            },
            output: { voice: "coral" }
          }
        }
      })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      return res.status(upstream.status).json({ error: data?.error?.message || "Realtime session setup failed." });
    }
    return res.json({ client_secret: data.value, expires_at: data.expires_at });
  } catch {
    return res.status(500).json({ error: "Could not create a Realtime session." });
  }
});

const port = Number(process.env.PORT || 8787);
app.listen(port, () => console.log(`HELLO AI backend listening on ${port}`));
