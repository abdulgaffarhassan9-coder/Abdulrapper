# HELLO AI 🤖 — starter project

This is the first runnable project scaffold for a cross-platform Flutter app and a small
Node.js backend. It is **not yet a finished, tested voice app**: the Flutter screen is the
UI foundation and the backend securely creates short-lived OpenAI Realtime client secrets.
The native WebRTC audio-session adapter and device testing are the next implementation step.

## Project layout

- `mobile/` — Flutter app for iOS and Android
- `backend/` — Node.js endpoint that keeps the permanent OpenAI API key off the phone

## Requirements

- Flutter stable + Xcode on a Mac for building/signing iOS
- Android Studio for Android builds
- Node.js 20+ for the backend
- An OpenAI API key with Realtime API access

An iPhone alone cannot compile/sign a native iOS app. You can review the source on iPhone,
but an iOS build needs macOS/Xcode or a compatible cloud build service.

## Start the backend

```bash
cd backend
cp .env.example .env
# Put your API key in backend/.env. Never put it in the Flutter app.
npm install
npm start
```

The backend exposes `POST /realtime-token`. The app must call this endpoint through HTTPS
in production. For local development, use your computer's LAN address, not `localhost`
from the phone.

## Start the Flutter UI

```bash
cd mobile
flutter pub get
flutter run
```

Set `API_BASE_URL` in `mobile/lib/main.dart` to your backend URL before running.

## Voice integration

The backend creates a short-lived client secret using the current Realtime client-secret
endpoint. The mobile app must use that temporary secret to establish a WebRTC session;
never embed `OPENAI_API_KEY` in the app. The selected voice is `coral` as a feminine-sounding
starting point; actual Hausa pronunciation and voice quality must be tested with speakers.

Official docs:
- https://developers.openai.com/api/docs/guides/realtime
- https://developers.openai.com/api/docs/guides/voice-webrtc
- https://developers.openai.com/api/reference/resources/realtime/subresources/client_secrets/methods/create
