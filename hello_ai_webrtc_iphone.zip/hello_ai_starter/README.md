# HELLO AI 🤖 — starter project

This is the first runnable project scaffold for a cross-platform Flutter app and a small
Node.js backend. It is **not yet a finished, tested voice app**: the Flutter screen is the
UI foundation and the backend securely creates short-lived OpenAI Realtime client secrets.
The native WebRTC audio-session adapter and device testing are the next implementation step.

## Project layout

- `mobile/` — Flutter app for iOS and Android
- `backend/` — Node.js endpoint that keeps the permanent OpenAI API key off the phone

## Requirements

- Flutter stable + Xcode on a Mac for building/signing iOS
- Android Studio for Android builds
- Node.js 20+ for the backend
- An OpenAI API key with Realtime API access

An iPhone alone cannot compile/sign a native iOS app. You can review the source on iPhone,
but an iOS build needs macOS/Xcode or a compatible cloud build service.

## Start the backend

```bash
cd backend
cp .env.example .env
# Put your API key in backend/.env. Never put it in the Flutter app.
npm install
npm start
```

The backend exposes `POST /realtime-token`. The app must call this endpoint through HTTPS
in production. For local development, use your computer's LAN address, not `localhost`
from the phone.

## Start the Flutter UI

```bash
cd mobile
flutter pub get
flutter run
```

Set `API_BASE_URL` in `mobile/lib/main.dart` to your backend URL before running.

## Voice integration

The backend creates a short-lived client secret using the current Realtime client-secret
endpoint. The mobile app must use that temporary secret to establish a WebRTC session;
never embed `OPENAI_API_KEY` in the app. The selected voice is `coral` as a feminine-sounding
starting point; actual Hausa pronunciation and voice quality must be tested with speakers.

Official docs:
- https://developers.openai.com/api/docs/guides/realtime
- https://developers.openai.com/api/docs/guides/voice-webrtc
- https://developers.openai.com/api/reference/resources/realtime/subresources/client_secrets/methods/create


## WebRTC voice update (0.2)

The Flutter screen now:
1. Requests microphone permission.
2. Gets a short-lived client secret from the Node backend.
3. Creates a WebRTC peer connection and microphone audio track.
4. Sends an SDP offer to the OpenAI Realtime calls endpoint.
5. Applies the SDP answer and receives assistant audio.
6. Opens a data channel for transcript events.

Important:
- Replace `apiBaseUrl` in `mobile/lib/main.dart` with your deployed HTTPS backend URL.
- Add the microphone permission entries from `mobile/IOS_PERMISSIONS.txt` and
  `mobile/ANDROID_PERMISSIONS.txt`.
- The code needs to be built and tested on a physical iPhone. This environment has not
  run Flutter/Xcode or validated audio behavior on your device.
- If your account's Realtime API rejects the selected model or session schema, use the
  model/session configuration currently shown in the official Realtime docs.
