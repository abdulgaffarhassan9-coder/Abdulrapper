import 'dart:async';
import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:http/http.dart' as http;

// Use your deployed HTTPS backend URL. Do not place your permanent OpenAI key here.
const apiBaseUrl = 'https://YOUR_BACKEND_HOST';

void main() => runApp(const HelloAiApp());

class HelloAiApp extends StatelessWidget {
  const HelloAiApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'HELLO AI',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF090D18),
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF8B5CF6),
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
        ),
        home: const VoiceHome(),
      );
}

class VoiceHome extends StatefulWidget {
  const VoiceHome({super.key});

  @override
  State<VoiceHome> createState() => _VoiceHomeState();
}

class _VoiceHomeState extends State<VoiceHome> {
  RTCPeerConnection? _peer;
  RTCDataChannel? _channel;
  MediaStream? _localStream;
  StreamSubscription<RTCDataChannelMessage>? _channelSub;

  bool _connecting = false;
  bool _connected = false;
  String _status = 'A shirye nake in saurareka.';
  final List<String> _transcript = [];

  // Realtime events may contain user transcription and assistant transcript.
  void _handleRealtimeEvent(String raw) {
    try {
      final event = jsonDecode(raw) as Map<String, dynamic>;
      final type = event['type'] as String? ?? '';
      final text = (event['transcript'] ??
              event['delta'] ??
              event['text'] ??
              '') as String;
      if (text.isEmpty) return;

      if (type == 'conversation.item.input_audio_transcription.completed' ||
          type == 'response.audio_transcript.done' ||
          type == 'response.output_audio_transcript.done') {
        final who = type.contains('input_audio') ? 'Kai' : 'Hello AI';
        if (mounted) setState(() => _transcript.add('$who: $text'));
      }
    } catch (_) {
      // Ignore non-JSON or unrecognized events; audio continues independently.
    }
  }

  Future<void> _startVoice() async {
    if (_connecting || _connected) return;
    setState(() {
      _connecting = true;
      _status = 'Ana neman izinin microphone...';
    });

    try {
      // 1) Get a short-lived client secret from our own backend.
      final tokenResponse = await http.post(
        Uri.parse('$apiBaseUrl/realtime-token'),
        headers: {'Content-Type': 'application/json'},
      );
      if (tokenResponse.statusCode != 200) {
        throw Exception('Backend error ${tokenResponse.statusCode}');
      }
      final tokenJson = jsonDecode(tokenResponse.body) as Map<String, dynamic>;
      final ephemeralKey = tokenJson['client_secret'] as String?;
      if (ephemeralKey == null || ephemeralKey.isEmpty) {
        throw Exception('Missing temporary client secret');
      }

      if (mounted) setState(() => _status = 'Ana kunna haɗin murya...');

      // 2) Request microphone permission and create a peer connection.
      _localStream = await navigator.mediaDevices.getUserMedia({
        'audio': {
          'echoCancellation': true,
          'noiseSuppression': true,
          'autoGainControl': true,
        },
        'video': false,
      });

      _peer = await createPeerConnection({
        'sdpSemantics': 'unified-plan',
      });

      for (final track in _localStream!.getAudioTracks()) {
        await _peer!.addTrack(track, _localStream!);
      }

      // 3) Receive assistant audio from the remote peer.
      _peer!.onTrack = (RTCTrackEvent event) {
        if (event.streams.isNotEmpty) {
          // flutter_webrtc attaches remote audio to the platform audio renderer.
          // The audio track is played by the native WebRTC audio session.
        }
      };

      // 4) Data channel carries transcripts, errors and response events.
      final dcInit = RTCDataChannelInit()..ordered = true;
      _channel = await _peer!.createDataChannel('oai-events', dcInit);
      _channelSub = _channel!.onMessage.listen((message) {
        if (!message.isBinary) _handleRealtimeEvent(message.text);
      });

      // 5) Create SDP offer and exchange it directly with OpenAI using ephemeral key.
      final offer = await _peer!.createOffer({
        'offerToReceiveAudio': true,
        'offerToReceiveVideo': false,
      });
      final iceGathered = Completer<void>();
      _peer!.onIceGatheringState = (state) {
        if (state == RTCIceGatheringState.RTCIceGatheringStateComplete &&
            !iceGathered.isCompleted) {
          iceGathered.complete();
        }
      };
      await _peer!.setLocalDescription(offer);
      // Wait for ICE candidates so the SDP sent to OpenAI is complete.
      if (_peer!.iceGatheringState !=
          RTCIceGatheringState.RTCIceGatheringStateComplete) {
        await iceGathered.future.timeout(const Duration(seconds: 12));
      }

      final local = await _peer!.getLocalDescription();
      if (local?.sdp == null) throw Exception('Could not create SDP offer');

      final sdpResponse = await http.post(
        Uri.parse('https://api.openai.com/v1/realtime/calls'),
        headers: {
          'Authorization': 'Bearer $ephemeralKey',
          'Content-Type': 'application/sdp',
        },
        body: local!.sdp,
      );

      if (sdpResponse.statusCode < 200 || sdpResponse.statusCode >= 300) {
        throw Exception('Realtime connection error ${sdpResponse.statusCode}');
      }

      await _peer!.setRemoteDescription(
        RTCSessionDescription(sdpResponse.body, 'answer'),
      );

      if (!mounted) return;
      setState(() {
        _connected = true;
        _status = 'An haɗa! Yi magana da Hello AI.';
      });
    } catch (e) {
      await _disposeVoice();
      if (!mounted) return;
      setState(() {
        _connected = false;
        _status = 'Haɗin bai yi nasara ba. Duba backend, intanet da saitunan.';
      });
    } finally {
      if (mounted) setState(() => _connecting = false);
    }
  }

  Future<void> _stopVoice() async {
    await _disposeVoice();
    if (mounted) {
      setState(() {
        _connected = false;
        _status = 'An dakatar da tattaunawa.';
      });
    }
  }

  Future<void> _disposeVoice() async {
    await _channelSub?.cancel();
    _channelSub = null;
    try {
      await _channel?.close();
    } catch (_) {}
    _channel = null;
    try {
      await _peer?.close();
    } catch (_) {}
    _peer = null;
    for (final track in _localStream?.getTracks() ?? <MediaStreamTrack>[]) {
      await track.stop();
    }
    await _localStream?.dispose();
    _localStream = null;
  }

  @override
  void dispose() {
    _channelSub?.cancel();
    _channel?.close();
    _peer?.close();
    for (final track in _localStream?.getTracks() ?? <MediaStreamTrack>[]) {
      track.stop();
    }
    _localStream?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('HELLO AI 🤖',
              style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: true,
          backgroundColor: Colors.transparent,
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              children: [
                const SizedBox(height: 20),
                Container(
                  width: 132,
                  height: 132,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [Color(0xFF8B5CF6), Color(0xFF2563EB)],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF8B5CF6).withOpacity(.28),
                        blurRadius: 36,
                        spreadRadius: 4,
                      )
                    ],
                  ),
                  child: const Icon(Icons.graphic_eq_rounded,
                      size: 66, color: Colors.white),
                ),
                const SizedBox(height: 20),
                const Text('BARKA! NI CE HELLO AI',
                    style:
                        TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text(_status,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white.withOpacity(.68))),
                const SizedBox(height: 22),
                Expanded(
                  child: ListView.separated(
                    itemCount: _transcript.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, index) => Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        padding: const EdgeInsets.all(13),
                        decoration: BoxDecoration(
                          color: const Color(0xFF171E30),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.white12),
                        ),
                        child: Text(_transcript[index]),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 88,
                  height: 88,
                  child: FilledButton(
                    onPressed: _connecting
                        ? null
                        : (_connected ? _stopVoice : _startVoice),
                    style: FilledButton.styleFrom(
                      shape: const CircleBorder(),
                      backgroundColor: _connected
                          ? const Color(0xFFDC405B)
                          : const Color(0xFF7C3AED),
                    ),
                    child: _connecting
                        ? const CircularProgressIndicator()
                        : Icon(_connected ? Icons.call_end : Icons.mic,
                            size: 38),
                  ),
                ),
                const SizedBox(height: 10),
                Text(_connected ? 'Danna domin dakatarwa' : 'Danna domin magana',
                    style: const TextStyle(
                        color: Colors.white60, fontSize: 12)),
              ],
            ),
          ),
        ),
      );
}
